const Discord = require('discord.js');
const client = new Discord.Client();
const token = process.env.BOT_TOKEN;

exports.handler = (event, context) => {
    client.on('ready', () => {
        console.log(`Logged in as ${client.user.tag}!`);
        client.channels.fetch("849378744531812372").then(
            chan => chan.send(JSON.stringify(event)),
            err => console.log(err)
        ).then(() => client.destroy()
        )
    });

    client.on('message', async msg => {
        if (msg.content === 'ping') {
            await msg.reply("pong");
        }
    });

    client.login(token).then();
}
